import java.util.Scanner;
class Task01{
public static void main (String args[]){
int start = 2;
int end = 10;
for(int num=start;num<=end;num++){
boolean isPrime=true;
for(int i=2; i<num;i++){
if (num %i==0){
isPrime=false;
break;
}
}
if (isPrime){
System.out.println("Yes Prime Number");
}else{
System.out .println ("Not Prime Number ");
}
}
}
}
