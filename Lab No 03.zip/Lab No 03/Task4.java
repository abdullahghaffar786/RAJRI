public class Task4 {
    public static void main(String[] args) {
        int[] array = new int[10];
        int i = 0;
        do {
            array[i] = (i + 1) * (i + 1); 
            i++;
        } while (i < 10);
        int oddSum = 0;
        int j = 0;
        while (j < array.length) {
            if (array[j] % 2 != 0) {
                oddSum += array[j];
            }
            j++;
        }
        System.out.println("Sum of odd numbers: " + oddSum);

        for (int k = 0; k < array.length; k++) {
            if (array[k] == 81) {
                System.out.println("81 encountered, breaking the loop.");
                break;
            }
        }
    }
}
