import java.util.Scanner;

public class SeatReservationSystem {
    static final int ROWS = 5;
    static final int COLS = 5;
    public static void displaySeats(boolean[][] seats) {
        for (int i = 0; i < ROWS; i++) {
            for (int j = 0; j < COLS; j++) {
                System.out.print(seats[i][j] ? "[X] " : "[ ] ");
            }
            System.out.println();
        }
    }
    
    public static void main(String[] args) {
        boolean[][] seats = new boolean[ROWS][COLS];
        Scanner scanner = new Scanner(System.in);
        int choice;
        
        do {
            System.out.println("1. Display available seats");
            System.out.println("2. Reserve a seat");
            System.out.println("3. Exit");
            System.out.print("Enter your choice: ");
            choice = scanner.nextInt();
            
            switch (choice) {
                case 1:
                    System.out.println("\nAvailable Seats:");
                    displaySeats(seats);
                    break;
                    
                case 2:
                    System.out.print("Enter the row number (1-" + ROWS + "): ");
                    int row = scanner.nextInt();
                    System.out.print("Enter the column number (1-" + COLS + "): ");
                    int col = scanner.nextInt();
                    if (row < 1 || row > ROWS || col < 1 || col > COLS) {
                        System.out.println("Invalid range");
                    } else if (seats[row - 1][col - 1]) {
                        System.out.println("Seat is already reserved.");
                    } else {
                        seats[row - 1][col - 1] = true;
                        System.out.println("Seat reserved successfully!");
                    }
                    break;
                    
                case 3:
                    System.out.println("Exiting the system...");
                    break;
                    
                default:
                    System.out.println("Invalid choice");
            }
        } while (choice != 3); 
        
        scanner.close();
    }
}
