class Main {
    public static void main(String[] args) {
        Shape shapeRef;
        shapeRef = new Circle();
        shapeRef.draw(); 
        shapeRef = new Rectangle();
        shapeRef.draw();  
    }
}