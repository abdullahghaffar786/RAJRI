Class GraduateStudent extends Student{
    String researchTopic;
    Student(String name,int age,int Studentid, String researchTopic){
        super(name age Studentid)
        this.researchTopic=researchTopic;
}
Void displayinfo(){
        System.out.println("name"+super.name);
        System.out.println("age"+super.age);
        System.out.println("Studentid"+super.Studentid);
        System.out.println("researchTopic"+researchTopic);
}
}