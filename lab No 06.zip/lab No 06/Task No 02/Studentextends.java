Class Student extends Person{
    int Studentid;
    Student(String name,int age,int Studentid){
        super(name,age);
        this.Studentid =Studentid;
    }
    void displayinfo(){
        System.out.println("name"+super.name);
        System.out.println("age"+super.age);
        System.out.println("Studentid"+Studentid);
    }
}