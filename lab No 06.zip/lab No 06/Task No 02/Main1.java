Class Main{
    public static void main(String [] args){
        GraduateStudent.Gs1=new GraduateStudent ("Abdullah",23,054,"java");
        Gs1.displayinfo();

    }
}