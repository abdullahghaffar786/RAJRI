class Main {
    public static void main(String[] args) {
        Car myCar = new Car("Toyota", 180, 4);
        Bike myBike = new Bike("Yamaha", 120, "Full Face");

        System.out.println("Car Details:");
        myCar.showDetails();

        System.out.println("\nBike Details:");
        myBike.showDetails();
    }
}