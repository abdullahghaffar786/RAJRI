class Main{
    public static void main(String[] args) {
        Dog D1 = new Dog("Rango", 3);
        D1.makeSound();
    }
}